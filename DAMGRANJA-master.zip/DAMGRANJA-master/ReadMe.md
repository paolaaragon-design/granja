# Práctica de Motores de Videojuegos I - UCIC ðŸŽ®

## ðŸ§‘ Nombre del alumno/a:
**Nombre(s):** [Paola Montserrat Aragón López]  
**Iniciales:** [PMAL]

## ðŸ—‚ï¸ Práctica #
**Título de la práctica:** [lagranjadedam]  
**Fecha de entrega:** [16/08/2025]

## ðŸ§  DescripciÃ³n
[Explica brevemente en que consiste la práctica, qué hiciste y que aprendiste. Ejemplo: En esta práctica implementa el movimiento de un personaje 2D usando Rigidbody2D y controles de teclado en Unity.]

## ðŸŽ® Instrucciones de uso
[Describe cÃ³mo ejecutar el proyecto: versiÃ³n de Unity, plataforma objetivo, controles, etc.]

Ejemplo:
- Unity versiÃ³n: UNITY 6 (6000.044F1)
- Plataforma: PC
- Controles: Teclas de flecha para moverse, espacio para saltar

## ðŸ“ Estructura del proyecto
[Opcional: describe o muestra la estructura básica del proyecto, carpetas principales o assets relevantes.]

## ðŸ™Œ Créditos
Este proyecto se desarrollÃ³ como parte de la materia **Motores de Videojuegos I** en la **Universidad UCIC**, durante el ciclo [Mayo-Agosto 2025].

Se utilizaron las siguientes plantillas o recursos base:
- [https://cupnooble.itch.io/sprout-lands-asset-pack]


---

